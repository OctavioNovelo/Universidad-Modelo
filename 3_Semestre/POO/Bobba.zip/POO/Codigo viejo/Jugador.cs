class Jugador
{
    public string nombre;
    public int vida;
    public int ataque;
    public int nivel;

    public void Atacar(Jugador atacado)
    {
        atacado.vida -= ataque;

        Console.WriteLine();
        Console.WriteLine(nombre + " ataco a " + atacado.nombre);
        Console.WriteLine(atacado.nombre + " tiene " + atacado.vida + " de vida"); 
    }

    public void MostarStats()
    {
        Console.WriteLine();
        Console.WriteLine(nombre);
        Console.WriteLine("vida: " + vida);
        Console.WriteLine("ataque: " + ataque);
        Console.WriteLine("Nivel: " + nivel);
    }
}