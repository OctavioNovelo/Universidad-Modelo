using System.Text.Json.Nodes;

class Pokemon
{
    public string nombre;
    public List<string> tipos;
    public int vida;
    public int ataque;
    public int nivel;

    public void Atacar()
    {
        Console.WriteLine(nombre + " ataco");

    }

    public Pokemon()
    {
        nombre = "Mising No";
        tipos = new List<string>();
        vida = 100;
        ataque = 20;
        nivel = 1;
    }

    public Pokemon(string nombre, int vida, int ataque)
    {
        this.nombre = nombre;
        this.tipos = new List<string>{"Normal"};
        this.vida = vida;
        this.ataque = ataque;
        this.nivel = 1;
    }

    public Pokemon(PokemonJson data)
    {
        this.nombre = data.name;
        this.tipos = data.type;
        this.vida = data.hp;
        this.ataque = data.Attack;
        this.nivel = 1;
        
    }
    public void MostrarInformacion()
    {
        Console.WriteLine($"=== Pokémon: {nombre} (Nivel {nivel}) ===");
        Console.WriteLine($"Tipos: {string.Join(", ", tipos)}");
        Console.WriteLine($"Vida (HP): {vida}");
        Console.WriteLine($"Ataque: {ataque}");
        Console.WriteLine("==================================\n");
    }

}