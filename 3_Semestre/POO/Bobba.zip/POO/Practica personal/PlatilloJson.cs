using System.Collections.Generic;
using System.Text.Json.Serialization;

public class PlatilloJson
{
    [JsonPropertyName("nombre")]
    public List<string> nombre { get; set; } = new List<string>();

    [JsonPropertyName("precio")]
    public int precio { get; set; }

}