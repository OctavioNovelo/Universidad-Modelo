using System.Security.Cryptography;

class Platillo
{
    public string nombre;
    public int precio;


    public Platillo(string comida, int precio )
    {
        this.nombre = comida;
        this.precio = precio;

    }

    public void ServicioHabitacion(Habitacion cliente)
    {
        cliente.cuenta += this.precio;
    }

    public void canjearDesayuno(Habitacion cliente)
    {
        if(cliente.cupon-1 > 0)
        {
            Console.WriteLine("cupones de la habitacion gastados");
        }
        else
        {    
            cliente.cupon -= 1;
        }
    }
}
