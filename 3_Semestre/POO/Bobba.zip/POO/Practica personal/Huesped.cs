
class Huesped
{
    public string nombre;
    public int numeroHabitacion;
    public int estancia;
    

    public Huesped(string huesped, int dias)
    {
        nombre = huesped;
        estancia = dias;
        
    }
    public Huesped(string huesped, int dias, string habitacion)
    {
        nombre = huesped;
        estancia = dias;
        
    }


    public void MostrarInformacion()
    {
        Console.WriteLine($"huesped: {nombre}");
        Console.WriteLine($"Estancia: {estancia} dias");
         Console.WriteLine($"Habitaciom: {numeroHabitacion}");
        Console.WriteLine("");
    }

    public void ExpandirEstancia(int extra)
    {
        this.estancia += extra;
        Console.WriteLine("");
    }




}