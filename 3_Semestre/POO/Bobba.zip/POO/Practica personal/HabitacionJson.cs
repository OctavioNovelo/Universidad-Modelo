using System.Collections.Generic;
using System.Text.Json.Serialization;

public class HabitacionJson
{
    [JsonPropertyName("numero")]
    public int numero { get; set; }

    [JsonPropertyName("tipo_de_cuarto")]
    public string tipo_de_cuarto { get; set; } = "";

    [JsonPropertyName("estado_de_habitacion")]
    public bool estado_de_habitacion { get; set; }
}