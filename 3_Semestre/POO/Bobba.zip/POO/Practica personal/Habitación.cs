

class Habitacion
{
    public int numero;
    public string tipo_de_cuarto;
    public bool estado;
    public int cuenta = 0;
    public int cupon = 3;

    public Habitacion()
    {
        this.numero = 1;
        this.tipo_de_cuarto = "basico";
        this.estado = false;
        
    }

    public Habitacion(HabitacionJson data)
    {
        this.numero = data.numero;
        this.tipo_de_cuarto = data.tipo_de_cuarto;
        this.estado = data.estado_de_habitacion;
    }

    public void ChecIn(Huesped cliente, string cuarto)
    {

        cliente.numeroHabitacion =  this.numero;
        this.tipo_de_cuarto = cuarto;
        this.estado = false;
    }

    public void Cuenta()
    {   
        Console.WriteLine($"Cuenta de la habitecion: {cuenta}$");
    }

    
}