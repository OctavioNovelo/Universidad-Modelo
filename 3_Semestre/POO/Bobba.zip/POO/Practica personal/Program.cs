﻿using System.Globalization;
using System.Text.Json;

class Program
{
    static void Main()
    {   
        string json = File.ReadAllText("Habitaciones.json");
        List<HabitacionJson> data = JsonSerializer.Deserialize<List<HabitacionJson>>(json);
        
        Huesped Juan = new Huesped("juan", 3);
        Platillo taco = new Platillo("taco", 100);
        Habitacion cuarto = new Habitacion(data[1]);
        taco.ServicioHabitacion(cuarto);
        cuarto.ChecIn(Juan, "suit");
        Juan.MostrarInformacion();
        cuarto.Cuenta();


        
        
    }
}
